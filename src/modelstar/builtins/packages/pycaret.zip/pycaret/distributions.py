from pycaret.internal.distributions import (
    CategoricalDistribution,
    DiscreteUniformDistribution,
    IntUniformDistribution,
    UniformDistribution,
)
