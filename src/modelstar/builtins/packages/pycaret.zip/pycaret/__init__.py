from pycaret.utils import __version__
from pycaret.utils._show_versions import show_versions

__all__ = ["show_versions", "__version__"]
