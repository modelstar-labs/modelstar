class MissingDataError(Exception):
    """
    Error raised if variables contain missing values when forbidden
    """

    pass
